package com.books.peanut.qna.store;

public interface QnaStore {

}
