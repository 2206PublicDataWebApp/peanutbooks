package com.books.peanut.qna.store.logic;

import org.springframework.stereotype.Repository;

import com.books.peanut.qna.store.QnaStore;
@Repository
public class QnaStoreLogic implements QnaStore {

}
