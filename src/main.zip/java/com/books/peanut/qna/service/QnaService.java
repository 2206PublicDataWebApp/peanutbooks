package com.books.peanut.qna.service;

public interface QnaService {

}
