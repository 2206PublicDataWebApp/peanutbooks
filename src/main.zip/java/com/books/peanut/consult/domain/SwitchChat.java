package com.books.peanut.consult.domain;

public class SwitchChat {
	private String on_off;

	public String getOn_off() {
		return on_off;
	}

	public void setOn_off(String on_off) {
		this.on_off = on_off;
	}
	
	

}
